package edu.northeastern.a6;

import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.constraintlayout.widget.ConstraintSet;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class WeatherActivity extends AppCompatActivity {

    private EditText etLatitude;
    private EditText etLongitude;
    private Button btnGetWeather;
    private Button btnToggle;
    private ConstraintLayout clWeatherInfo;
    private boolean showDetailed = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weather);

        etLatitude = findViewById(R.id.latitude_input);
        etLongitude = findViewById(R.id.longitude_input);
        btnGetWeather = findViewById(R.id.fetch_weather_button);
        btnToggle = findViewById(R.id.toggle_button);
        clWeatherInfo = findViewById(R.id.weather_info_layout);

        btnGetWeather.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String latitude = etLatitude.getText().toString();
                String longitude = etLongitude.getText().toString();
                if (!latitude.isEmpty() && !longitude.isEmpty()) {
                    new GetWeatherTask().execute(latitude, longitude);
                }
            }
        });

        btnToggle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDetailed = !showDetailed;
                btnToggle.setText(showDetailed ? "Show Simple" : "Show Detailed");
            }
        });
    }

    private class GetWeatherTask extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... params) {
            String latitude = params[0];
            String longitude = params[1];
            String response = "";
            try {
                String urlString = "https://api.open-meteo.com/v1/forecast?latitude=" + latitude + "&longitude=" + longitude + "&hourly=temperature_2m,precipitation,humidity_2m,windspeed_10m,sunrise,sunset";
                URL url = new URL(urlString);
                HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestMethod("GET");

                BufferedReader reader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                StringBuilder content = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    content.append(line);
                }
                response = content.toString();
                urlConnection.disconnect();
                reader.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
            return response;
        }

        @Override
        protected void onPostExecute(String result) {
            if (result != null && !result.isEmpty()) {
                clWeatherInfo.removeAllViews();
                try {
                    JSONObject jsonObject = new JSONObject(result);
                    JSONArray hourly = jsonObject.getJSONArray("hourly");
                    for (int i = 0; i < hourly.length(); i++) {
                        JSONObject hourData = hourly.getJSONObject(i);
                        StringBuilder weatherInfo = new StringBuilder();
                        weatherInfo.append("Temperature: ").append(hourData.getDouble("temperature_2m")).append("°C\n");
                        weatherInfo.append("Precipitation: ").append(hourData.getDouble("precipitation")).append("mm");

                        if (showDetailed) {
                            weatherInfo.append("\nHumidity: ").append(hourData.getDouble("humidity_2m")).append("%");
                            weatherInfo.append("\nWind Speed: ").append(hourData.getDouble("windspeed_10m")).append(" km/h");
                            weatherInfo.append("\nSunrise: ").append(hourData.getString("sunrise"));
                            weatherInfo.append("\nSunset: ").append(hourData.getString("sunset"));
                        }

                        ConstraintLayout weatherItemLayout = new ConstraintLayout(WeatherActivity.this);
                        ConstraintSet constraintSet = getConstraintSetForWeatherItem(weatherInfo.toString());
                        constraintSet.applyTo(weatherItemLayout);
                        clWeatherInfo.addView(weatherItemLayout);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    TextView errorText = new TextView(WeatherActivity.this);
                    errorText.setText("Failed to retrieve weather data.");
                    clWeatherInfo.addView(errorText);
                }
            } else {
                TextView errorText = new TextView(WeatherActivity.this);
                errorText.setText("Failed to retrieve weather data.");
                clWeatherInfo.addView(errorText);
            }
        }
    }

    private ConstraintSet getConstraintSetForWeatherItem(String weatherInfo) {
        ConstraintSet constraintSet = new ConstraintSet();
        ConstraintLayout.LayoutParams layoutParams = new ConstraintLayout.LayoutParams(
                ConstraintLayout.LayoutParams.WRAP_CONTENT,
                ConstraintLayout.LayoutParams.WRAP_CONTENT
        );

        TextView textView = new TextView(this);
        textView.setText(weatherInfo);
        textView.setId(View.generateViewId());
        textView.setLayoutParams(layoutParams);

        constraintSet.clone(clWeatherInfo);
        constraintSet.connect(textView.getId(), ConstraintSet.TOP, ConstraintSet.PARENT_ID, ConstraintSet.TOP);
        constraintSet.connect(textView.getId(), ConstraintSet.START, ConstraintSet.PARENT_ID, ConstraintSet.START);
        constraintSet.connect(textView.getId(), ConstraintSet.END, ConstraintSet.PARENT_ID, ConstraintSet.END);
        constraintSet.constrainHeight(textView.getId(), ConstraintSet.WRAP_CONTENT);

        return constraintSet;
    }
}